//
//  ViewController.swift
//  CodableDemo
//
//  Created by admin on 10/07/19.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit


let json = """
{
"name": "Enterprise D",
"captain": "Jean Luc Picard",
"max_warp_speed": 9.6
}
"""

let json1 = """
[
{
"name": "Enterprise D",
"captain": "Jean Luc Picard",
"max_warp_speed": 9.6
},
{
"name": "Defiant",
"captain": "Benjamin Sisko",
"max_warp_speed": 9.2
},
{
"name": "Voyager",
"captain": "Captain Kathryn Janeway",
"max_warp_speed": 9.975
}
]
"""

let json2 = """
[
    {
        "name": "Enterprise D",
        "captain": "Jean Luc Picard",
        "max_warp_speed": 9.6,
        "position": "Alpha quadrant"
    },
    {
        "name": "Defiant",
        "captain": "Benjamin Sisko",
        "max_warp_speed": 9.2,
        "position": "Alpha quadrant"
    },
    {
        "name": "Voyager",
        "captain": "Captain Kathryn Janeway",
        "max_warp_speed": 9.975,
        "position": null
    }
]
"""


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        initialSetup()
        let rawData = """
{
    "job_information": {
        "title": "iOS Developer",
        "salary": 5000
    },
    "firstname": "John",
    "lastname": "Doe",
    "age": 20
}
""".data(using: .utf8)!
        print(rawData)
        do {
            let person = try JSONDecoder().decode(Person.self, from: rawData)
            print(person.firstName) // John
            print(person.lastName) // Doe
            print(person.job.title) // iOS Developer
        }catch {
            print("Hello")
        }
    }

  
    
    private func initialSetup() {
        let data = json.data(using: .utf8)
        let data1 = json1.data(using: .utf8)
        let data2 = json2.data(using: .utf8)
        do {
            let decoder = JSONDecoder()
             decoder.keyDecodingStrategy = .convertFromSnakeCase
            
            let team = try decoder.decode(Team.self, from: data!)
            print(team.name)
            print(team.captain)
            print(team.maxWarpSpeed)
            
            let teamList = try decoder.decode([Team].self, from: data1!)
            
            teamList.forEach{
                print($0.maxWarpSpeed)
            }
            
            let teamSame = try JSONDecoder().decode(TeamSameName.self, from: data!)
            print(teamSame.max_warp_speed)
            
            let shipList = try decoder.decode([Ship].self, from: data2!)
            shipList.forEach{
                print($0.position ?? "")
            }
            
        } catch {
            print("Got bug")
        }
    }
}

struct Ship: Decodable {
    var name:String
    var captain:String
    var maxWarpSpeed:Double
    var position:String?
}

struct TeamSameName:Decodable {
    var name:String
    var captain:String
    var max_warp_speed:Double
}

struct Team : Decodable {
    var name:String
    var captain:String
    var maxWarpSpeed:Double
}

class Job: Decodable {
    var title: String
    var salary: Float
    
    init(title: String, salary: Float) {
        self.title = title
        self.salary = salary
    }
    
    enum CodingKeys: String, CodingKey {
        case title, salary
    }
}

class Person: Decodable {
    var job: Job
    var firstName: String
    var lastName: String
    var age: Int
    
    init(job: Job, firstName: String, lastName: String, age: Int) {
        self.job = job
        self.firstName = firstName
        self.lastName = lastName
        self.age = age
    }
    
    enum CodingKeys: String, CodingKey {
        case job = "job_information", firstName = "firstname", lastName = "lastname", age
    }
}
